-- MySQL dump 10.13  Distrib 5.7.42, for Linux (x86_64)
--
-- Host: localhost    Database: school_db
-- ------------------------------------------------------
-- Server version	5.7.42-0ubuntu0.18.04.1

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `customers1`
--

DROP TABLE IF EXISTS `customers1`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `customers1` (
  `id` int(11) NOT NULL,
  `name` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `customers1`
--

LOCK TABLES `customers1` WRITE;
/*!40000 ALTER TABLE `customers1` DISABLE KEYS */;
/*!40000 ALTER TABLE `customers1` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `customers3`
--

DROP TABLE IF EXISTS `customers3`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `customers3` (
  `id` int(11) NOT NULL,
  `name` varchar(50) NOT NULL,
  `acc_type` varchar(50) NOT NULL DEFAULT 'Savings'
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `customers3`
--

LOCK TABLES `customers3` WRITE;
/*!40000 ALTER TABLE `customers3` DISABLE KEYS */;
INSERT INTO `customers3` VALUES (101,'Archana','Savings'),(102,'Sandhya','Savings'),(103,'Sanju','Savings');
/*!40000 ALTER TABLE `customers3` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `customers4`
--

DROP TABLE IF EXISTS `customers4`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `customers4` (
  `acc_no` int(11) NOT NULL,
  `name` varchar(50) NOT NULL,
  `acc_type` varchar(50) NOT NULL DEFAULT 'Savings',
  PRIMARY KEY (`acc_no`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `customers4`
--

LOCK TABLES `customers4` WRITE;
/*!40000 ALTER TABLE `customers4` DISABLE KEYS */;
INSERT INTO `customers4` VALUES (1001,'sanju','Savings'),(1002,'sandhya','Savings');
/*!40000 ALTER TABLE `customers4` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `customers5`
--

DROP TABLE IF EXISTS `customers5`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `customers5` (
  `acc_no` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(50) NOT NULL,
  `acc_type` varchar(50) NOT NULL DEFAULT 'Savings',
  PRIMARY KEY (`acc_no`)
) ENGINE=InnoDB AUTO_INCREMENT=1002 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `customers5`
--

LOCK TABLES `customers5` WRITE;
/*!40000 ALTER TABLE `customers5` DISABLE KEYS */;
INSERT INTO `customers5` VALUES (1,'Sandhya','Savings'),(2,'Sanju','Savings'),(1001,'Sanjay','Savings');
/*!40000 ALTER TABLE `customers5` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2026-01-03  0:57:08
